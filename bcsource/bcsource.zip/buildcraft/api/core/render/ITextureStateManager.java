package buildcraft.api.core.render;

import net.minecraft.util.IIcon;

public interface ITextureStateManager {
	void set(IIcon icon);
}
