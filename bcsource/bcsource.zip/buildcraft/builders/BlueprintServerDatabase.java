package buildcraft.builders;

public class BlueprintServerDatabase extends LibraryDatabase {

}
